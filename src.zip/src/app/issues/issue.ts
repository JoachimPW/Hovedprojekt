export class Issue {
    issueId: number;
    categoryId: number;
    name: string;
    problem: string;
    image: string;
    solution: string;
}