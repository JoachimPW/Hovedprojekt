import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'e-learning',
  templateUrl: './e-learning.component.html',
  styleUrls: ['./e-learning.component.css']
})
export class ELearningComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
