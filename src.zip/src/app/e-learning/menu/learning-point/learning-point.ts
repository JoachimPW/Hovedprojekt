export class LearningPoint {
    pointId: number;
    name: string;
}