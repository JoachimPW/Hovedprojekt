import { LearningPoint } from './learning-point';

export const LEARNINGPOINTS: LearningPoint[] = [
    { pointId: 1, name: 'Login' },
    { pointId: 2, name: 'Cancel printjob' },
    { pointId: 3, name: 'Resend printjob' },
    { pointId: 4, name: 'Add user' },
    { pointId: 5, name: 'Payment' }
];
