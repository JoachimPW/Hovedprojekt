import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { IssuesComponent } from './issues/issues.component';
import { HomeComponent } from './home/home.component';
import { ELearningComponent } from './e-learning/e-learning.component';

const routes: Routes = [
  { path: 'categories/:categoryId', component: IssuesComponent },
  { path: '', component: HomeComponent },
  { path: 'search', component: IssuesComponent },
  { path: 'E-learning', component: ELearningComponent },
  { path: 'learningPoints/:pointId', component: ELearningComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  declarations: []
})

export class AppRoutingModule { }
