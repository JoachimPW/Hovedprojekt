import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trouble-shooting',
  templateUrl: './trouble-shooting.component.html',
  styleUrls: ['./trouble-shooting.component.css']
})
export class TroubleShootingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
