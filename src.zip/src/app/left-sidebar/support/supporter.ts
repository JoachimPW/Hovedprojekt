export class Supporter {
    id: number;
    phone: string;
}