import { Supporter } from './supporter';

export const SUPPORTERS: Supporter[] = [
    { id: 1, phone: '+45 6179 6656' },
    { id: 2, phone: '+441919179600 (UK)' },
    { id: 3, phone: '+1 (914) 996 6565 (US)' }    
];